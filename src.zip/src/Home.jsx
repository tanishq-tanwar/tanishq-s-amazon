// import { useState, createContext } from "react";
import { Outlet } from "react-router-dom";
import { Menubar } from "./Menubar";
// export const MyContext = createContext('')

const Home = () => {
  // const [records, setRecords] = useState([])

  return(
    <>
      {/* <MyContext.Provider value={{records, setRecords}}> */}
        <h1>Home Component</h1>
        <Menubar/>
        <Outlet/>
      {/* </MyContext.Provider> */}
      <p>
      </p>
    </>
  )
}

export default Home