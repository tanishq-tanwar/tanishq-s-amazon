import { Link } from "react-router-dom"

export const Menubar = () => {
  return(
    <>
      <Link to='/'>Home</Link> &nbsp;&nbsp;&nbsp;
      <Link to='/save'>Save</Link> &nbsp;&nbsp;&nbsp;
      <Link to='/show'>Show</Link> &nbsp;&nbsp;&nbsp;
    </>
  )
}