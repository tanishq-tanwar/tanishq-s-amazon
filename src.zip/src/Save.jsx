import { useState } from "react"
// import { useContext } from "react"
// import { MyContext } from "./Home"
import axios  from "axios"

const Save = () => {
  const [data, setData] = useState({name:'', city:'', email:''})
  // const {setRecords} = useContext(MyContext)
  const handleChange = (e) => {
    setData({...data, [e.target.name]: e.target.value})
  }

  const handleClick = () => {
    axios.post('https://65ef1671ead08fa78a4fc190.mockapi.io/test',{
      ...data
    })
        .then(response=> {          
          console.log(response.data);          
        })
        .catch(error=> {          
          console.log(error);
        });
        setData({name:'', city:'', email:''})
  }

  return(
    <>
      <hr />
      Name: <input type="text" name="name" value={data.name} onChange={handleChange}/> <br />
      City: <input type="text" name="city" value={data.city} onChange={handleChange}/> <br />
      Email: <input type="text" name="email" value={data.email} onChange={handleChange}/> <br />
      <input type="button" value="Add" onClick={handleClick}/>
    </>
  )
}

export default Save