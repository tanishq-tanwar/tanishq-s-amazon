import { Routes, Route } from 'react-router-dom';
import Home from './Home';
import Show from './Show';
import Save from './Save';

function App() {
  return (
    <>
        <Routes>
          <Route path="/" element={<Home />}>
            <Route path="save" element={<Save />} />
            <Route path="show" element={<Show />} />
          </Route>
        </Routes>
    </>
  );
}

export default App;
