// import { useContext } from "react"
// import { MyContext } from "./Home"
import { useState, useEffect } from 'react';
import axios from 'axios';

const Show = () => {
  // const {records,setRecords} = useContext(MyContext)
  const [records, setRecords] = useState([]);
  
  useEffect(() => {
    axios
      .get('https://65ef1671ead08fa78a4fc190.mockapi.io/test')
      .then((response) => {
        setRecords(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const handleDel = (id) => {
    // const rcds = [...records];
    // rcds.splice(index,1);
    // setRecords(rcds);

    axios
      .delete(`https://65ef1671ead08fa78a4fc190.mockapi.io/test/${id}`)
      .then((response) => {
        console.log(response.data);
        const index = records.indexOf(response.data);
        console.log(index);
        
        // location.reload()
      })
      .catch((error) => {
        console.log(error);
      });
  };

  return (
    <>
      {records.map((row) => {
        return (
          <div key={row.id}>
            <h1>{row.name}</h1>
            <p>{row.city}</p>
            <p>{row.email}</p>
            <input type="button" value="X" onClick={() => handleDel(row.id)} />
          </div>
        );
      })}
    </>
  );
};

export default Show;
